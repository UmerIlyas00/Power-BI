This repo contains a Power BI project :

[Financial Report Project](https://github.com/imenbkr/Power-Bi-dashboards/tree/main/Project%202%20-%20Financial%20Report) is a Power BI dashboard that summarizes profits for a company by segment, country and more.
[Link to the report on novyPro](https://www.novypro.com/project/financial-report-7)

![Financial-Report](https://github.com/imenbkr/Power-Bi-dashboards/assets/104791884/f8bd1228-46fc-4fc1-b8cd-86a1f9ca8955)
